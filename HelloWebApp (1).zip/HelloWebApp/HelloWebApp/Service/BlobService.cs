﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using HelloWebApp.Models;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Azure.Storage.Auth;
using Microsoft.Azure.Storage.Blob;

namespace HelloWebApp.Service
{
    public class BlobService
    {

        private static async Task<NewTokenAndFrequency> TokenRenewerAsync(Object state, CancellationToken cancellationToken)
        {
            // Specify the resource ID for requesting Azure AD tokens for Azure Storage.
            // Note that you can also specify the root URI for your storage account as the resource ID.
            const string StorageResource = "https://storage.azure.com/";

            // Use the same token provider to request a new token.
            var authResult = await ((AzureServiceTokenProvider)state).GetAuthenticationResultAsync(StorageResource);

            // Renew the token 5 minutes before it expires.
            var next = (authResult.ExpiresOn - DateTimeOffset.UtcNow) - TimeSpan.FromMinutes(5);
            if (next.Ticks < 0)            {
                next = default(TimeSpan);
                Console.WriteLine("Renewing token...");
            }

            // Return the new token and the next refresh time.
            return new NewTokenAndFrequency(authResult.AccessToken, next);
        }

        public async Task<string> CreateBlob(TextBlob textBlob)
        {

            //https://docs.microsoft.com/en-us/azure/storage/common/storage-auth-aad-rbac-portal
            //https://docs.microsoft.com/en-us/azure/storage/common/storage-auth-aad-msi
            //Storage Blob Data Contributor

            string blobNameURL = "https://haribstorage.blob.core.windows.net/sample-container/" + textBlob.BlobName;



            // Get the initial access token and the interval at which to refresh it.
            AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();
            var tokenAndFrequency = await TokenRenewerAsync(azureServiceTokenProvider, CancellationToken.None);

            // Create storage credentials using the initial token, and connect the callback function
            // to renew the token just before it expires
            TokenCredential tokenCredential = new TokenCredential(tokenAndFrequency.Token,
                                                                    TokenRenewerAsync,
                                                                    azureServiceTokenProvider,
                                                                    tokenAndFrequency.Frequency.Value);

            StorageCredentials storageCredentials = new StorageCredentials(tokenCredential);
            //StorageCredentials storageCredentials = new StorageCredentials("hariraostorage", "Fv9WcvH98pSUYdlqPMjeUrhx9kUzOdvQuNHMsGIkm7/1SDSxFNfZjhQe0R65lgK7dOHWmwTKlCAwubd0TfsmnA==");

            // Create a blob using the storage credentials.
            CloudBlockBlob blob = new CloudBlockBlob(new Uri(blobNameURL),
                                                        storageCredentials);
            try
            {
                // Upload text to the blob.
                await blob.UploadTextAsync(textBlob.BlobText);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
                return exp.Message;
            }
            return "Success";
            //// Continue to make requests against Azure Storage.
            //// The token is automatically refreshed as needed in the background.
            //do
            //{
            //    // Read blob contents
            //    Console.WriteLine("Time accessed: {0} Blob Content: {1}",
            //                        DateTimeOffset.UtcNow,
            //                        await blob.DownloadTextAsync());

            //    // Sleep for ten seconds, then read the contents of the blob again.
            //    Thread.Sleep(TimeSpan.FromSeconds(10));
            //} while (true);

        }

    }
}