﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Azure.Storage.Auth;
using Microsoft.Azure.Storage.Blob;

namespace HelloWebApp.Models
{
    public class TextBlob
    {
          public string BlobName { get; set; }
          public string BlobText { get; set; }

        public TextBlob(string blobName, string bolbText)
        {
            this.BlobName = blobName;
            this.BlobText = bolbText;
        }
        

    }
}