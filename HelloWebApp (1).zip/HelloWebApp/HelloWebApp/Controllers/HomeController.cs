﻿using HelloWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using HelloWebApp.Service;
using System.Configuration;

namespace HelloWebApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
  
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Value of My String." + Environment.GetEnvironmentVariable("MyString");

            return View();
        }
        [HttpPost]
        public async Task<ActionResult> About(string blobName, string blobText)
        {
            
            TextBlob txtBlob = new TextBlob(blobName, blobText);
            ViewBag.Message = "Your application description page. Blob Name: " + blobName + " Blob Text: " + blobText;
            try
            {
                BlobService blobService = new BlobService();

                string message = await blobService.CreateBlob(txtBlob);
                ViewBag.Message = "Your application description page. Blob Message " + message;

            }
            catch(Exception exp)
            {
                ViewBag.Message = "Error :  " + exp.Message;
            }
            
            return View();
        }
    }
}